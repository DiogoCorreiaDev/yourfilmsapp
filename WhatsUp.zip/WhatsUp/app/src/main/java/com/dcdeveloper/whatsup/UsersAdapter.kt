package com.dcdeveloper.whatsup

import android.content.Context
import android.content.Intent
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.user_list_item.view.*
import android.R.attr.key
import android.support.v4.app.NotificationCompat.getExtras
import android.os.Bundle
import android.R.attr.key
import kotlinx.android.synthetic.main.message_list_item.view.*


class UsersAdapter (val items : ArrayList<String>, val context: Context) : RecyclerView.Adapter<ViewHolder>() {
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.user_list_item, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        p0?.username?.text = items.get(p1)

        p0.itemView.setOnClickListener(View.OnClickListener {
            //Log.i("CLICK", "CLICK"+p1.toString())

            //val intent = Intent(this, ChatActivity::class.java)
            //intent.putExtra

            val intent = Intent(context, ChatActivity::class.java)
            val mBundle = Bundle()
            mBundle.putString("email", items.get(p1))
            intent.putExtras(mBundle)
            startActivity(context, intent, mBundle)

            /*intent.putExtra("email", items.get(p1))
            intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(context, intent, )
*/
        })


    }
}

class ViewHolder (view: View) : RecyclerView.ViewHolder(view) {
    val username = view.usernameTextView
    val message = view.messageTextView
}