package com.dcdeveloper.whatsup

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.renderscript.Sampler
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseError
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import java.util.ArrayList
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.ValueEventListener



class ChatActivity : AppCompatActivity() {
    val mAuth = FirebaseAuth.getInstance()
    var realSender: String? = null
    var emailSelected: String? = null
    var chatEditText: EditText? = null
    var recyclerView: RecyclerView? = null
    var allMessages: ArrayList<Message> = ArrayList()
    var messageArray: ArrayList<String> = ArrayList()

    fun sendChat(view: View){

        chatEditText = findViewById(R.id.chatEditText)
        var message = Message(chatEditText?.text.toString(),mAuth.currentUser!!.email.toString(),emailSelected)
        var newMessage: DatabaseReference = FirebaseDatabase.getInstance().reference.child("messages").push()
        newMessage.setValue(message)
        Toast.makeText(this, "Message sent!", Toast.LENGTH_SHORT).show()
        getMessages()
    }

    fun getMessages() {

        allMessages.clear()
        messageArray.clear()

        var messagesRef = FirebaseDatabase.getInstance().reference.child("messages")

        messagesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
                println(p0!!.message)
            }

            override fun onDataChange(p0: DataSnapshot) {
                val children = p0!!.children
                children.forEach {

                    var messageSender = it.getValue<Message>(Message::class.java)!!.sender!!.toString()
                    var messageRecipient =  it.getValue<Message>(Message::class.java)!!.recipient!!.toString()
                    println("TIMESTAMP: "+it.getValue<Message>(Message::class.java)!!.timestampCreated!!.toString())
                    //println(messageRecipient)
                    //println(messageSender==realSender)
                    if ((messageSender==realSender) &&
                        (messageRecipient==emailSelected)) {
                        val message = it.getValue<Message>(Message::class.java)!!
                        println("MESSAGES SENDER"+message)
                        //senderMessages.add(message)
                        allMessages.add(message)
                    }

                    if (messageSender==emailSelected
                        && messageRecipient==realSender) {
                        val message = it.getValue<Message>(Message::class.java)!!
                        println("MESSAGES RECIPIENT"+message)
                        //recipientMessages.add(message)
                        allMessages.add(message)
                    }
                }

                allMessages.sortBy { it.getCreatedTimestampLong() }

                for (obj in allMessages) {
                    var message: String
                    if (obj.sender != realSender) {
                        message = "> "+obj.message
                    } else {
                        message = obj.message!!
                    }
                    messageArray?.add(message)
                    //println(obj.getCreatedTimestampLong())
                }
                recyclerView!!.adapter!!.notifyDataSetChanged()
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        emailSelected = intent.extras.get("email").toString()
        if (mAuth.currentUser != null){
            realSender = mAuth.currentUser!!.email.toString()
        } else {
            mAuth.signOut()
        }

        getMessages()

        recyclerView = findViewById(R.id.chatListView)
        recyclerView!!.adapter = MessagesAdapter(messageArray, this)
        val listLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = GridLayoutManager(this, 1)
        val dividerItemDecoration = DividerItemDecoration(recyclerView!!.getContext(), LinearLayoutManager.VERTICAL)
        recyclerView!!.addItemDecoration(dividerItemDecoration)



        title = "Chat with " + emailSelected
        Log.i("EMAIL", emailSelected)

    }

}