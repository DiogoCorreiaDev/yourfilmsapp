package com.dcdeveloper.whatsup

import android.R.string
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ServerValue.TIMESTAMP
import java.util.*
import com.google.firebase.database.Exclude






class Message {

    var message: String? = null
    var sender: String? = null
    var recipient: String? = null
    var timestampCreated: Any? = null

    constructor(message: String?, sender: String?, recipient: String?) {
        this.message = message
        this.sender = sender
        this.recipient = recipient
        this.timestampCreated = TIMESTAMP
    }
    constructor() :
            this("", "",
        ""
    )

    @Exclude
    fun getCreatedTimestampLong(): Long {
        return timestampCreated as Long
    }

}